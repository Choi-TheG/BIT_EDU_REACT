import React from "react";
import Comment from "./Comment";

const comments = [
    {
        name : "Christopher", 
        comment : "My Heart"
    },
    {
        name : "Bruno Mars",
        comment : "Talking to the moon"
    },
    {
        name : "John Legend",
        comment : "P.D.A"
    },
    {
        name : "Elon Musk",
        comment : "화성 갈끄니까~~"
    }
]


function CommentList(props){
    return (
        <div>
            {comments.map((comment)=>{
                return(
                    <Comment name={comment.name} comment={comment.comment} />
                );
            })}
        </div>
    );
}

export default CommentList;
 