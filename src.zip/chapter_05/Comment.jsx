import React from "react";

const styles={
    wrapper:{
        margin : 0,
        padding : 0,
        display : "flex",
        flexDirection: "row",
        border: "1px solid grey",
        borderRadius: 10
    },

    imageContainer: {},

    image :{
        width:50,
        height:50,
        borderRadian:25
    },

    contentContainer:{
        marginLeft: 5,
        display: "flex",
        flexDirection: "column",
        justifyContent: "center"
    },

    nameText:{
        color: "black",
        fontSize: 16,
        fontWeight:"bold"
    },

    commentText:{
        color : "black",
        fontSize : 16
    }

}

function Comment(props){
    return(
		<div style={styles.wrapper}>
			<div>
				<img src="logo192.png" alt="icon" style={styles.image}/>
			</div>
			<div style={styles.contentContainer}>
				<span style={styles.nameText}>{props.name}</span><br></br>
				<span style={styles.commentText}> {props.comment}</span>
			</div>
		</div>
		// <div>

		// </div>
		// <div>

		// </div>
    )
}

export default Comment;