import React,{useEffect, useState} from "react";

function Counter(props){
    // let count = 0;
    const [count, setCount] = useState(0); // hook
    const [cnt,setCnt] = useState(0);
    useEffect(()=>{
        setCount(count+1);
        console.log(count);
        return(()=>{
            console.log("unmount");
        });
    },[/*비어있는 의존성 배열을 실행하면 여러번 실행하지 않음*/cnt]);
    return(
        <div>
            <p>total click : {count}</p>
            <button onClick={()=>{
                // count += 1;
                // setCount(count+1);
                setCnt(cnt+1);
            }}>click</button>
            <button onClick={()=>{
                setCount(0);
            }}>reset</button>
        </div>
    );
}

export default Counter;
 