import React, {useState, useEffect} from "react";
import Toolbar from "./Toolbar";

function LoginPage(props){
    // isLoggedIn useState 생성
    const [isLoggedIn,setIsLoggedIn] = useState(false);
    {/*useEffect(()=>{
        setIsLoggedIn(true);
    });
*/}
    const handlerLogin=()=>{
        setIsLoggedIn(true);
    };
    const handlerLogout=()=>{
        setIsLoggedIn(false);
    };

    return(
        <div>
            <Toolbar
                isLoggedIn = {isLoggedIn}
                onClickLogin = {handlerLogin}
                onClickLogout = {handlerLogout}
            />
            <br/>
            <div>study with react</div>
        </div>
    );
}

export default LoginPage;