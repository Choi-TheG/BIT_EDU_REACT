import React from "react";

const styles ={
    wrapper: {
        padding: 16,
        display: "flex",
        flexDirection: "row",
        borderBottom:"1px solid grey"
    },
    greeting: {
        marginRight: 8,
    },
};

function Toolbar(props){
    {/*const [isLoggedIn, setIsLoggedIn] = useState(false); */}
    const {isLoggedIn, onClickLogin, onClickLogout} = props;

    return(
        <div>
            {/*<span>welcome@</span>
            <button>logout</button>
            <button>login</button>
    */}
            {props.isLoggedIn && <span style={styles.greeting}>welcome@</span>}

            {props.isLoggedIn?(
                <button onClick={props.onClickLogout}>Logout</button>
            ):(
                <button onClick={props.onClickLogin}>Login</button>
            )}
        </div>
    );
}

export default Toolbar;