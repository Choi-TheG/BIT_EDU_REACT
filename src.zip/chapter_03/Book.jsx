import React from "react";
// props = properties = 속성

function Book(props){
    return(
        <div>
            this book's name is {props.name}.
            <h3>{`this book is totally ${props.numOfPage} pages.`}</h3>
        </div>
    )
}

export default Book;
