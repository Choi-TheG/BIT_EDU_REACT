import React from "react";
import Book from "./Book";
// props = properties = 속성
/* Library 안에 Book이 tag(=component)로 들어감 => Library 또한 다른 function에 component로 들어 갈 수 있음
	= 중첩 컴포넌트 
    localhost:3000 로 실행 됨
    html로 열리면서 http://가 없는 이유
    : http가 없을 땐 index.html로 가도록 기본적으로 기능이 구현되어있음
    렌더링 : 엘리먼트를 browser로 구현시켜주는 것
    DOM : document object Model. XML 이나 HTML에 접근하기 위한 일종의 인터페이스
*/

function Library(props){
    return(
        <div>
            <h1>Welcome to {props.name} Library.</h1>
            <br></br>
            <Book name="처음 만난 파이썬" numOfPage={300} />
            <Book name="First JAVA" numOfPage='{400}' />
            <Book name="Web Application" numOfPage="{450}" />
            <input value="ab"></input>
            <br></br><br></br><br></br>
        </div>
    )
}

export default Library;
 