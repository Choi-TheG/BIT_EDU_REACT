use std::{path::PathBuf, fs};
use std::str;
use std::str::FromStr;
use std::fs::OpenOptions;
use std::io::Write;

fn init_data (path: PathBuf)
    -> Vec<Vec<usize>> { 
    // 44 : ,
    // 10 : \n
    // 45 : -
    // 46 : .
    let mut tmp = Vec::new();
    let mut buf = Vec::new();
    let mut buf1 = Vec::new();
    let mut c0 = 0;
    let mut c1 = 0;
    let mut bytes = if let Ok(b) = fs::read(path) {
        b.into_iter()
    }
    else {
        panic!();
    };
    loop {
        if let Some(b) = bytes.next() {
            if c0 == 0 { // 1st_line
                if b == 10 {
                    c0 = 1;
                }
            }
            else {
                if c1 == 0 { // date
                    if b == 44 {
                        buf1.push(
                            if let Ok(f) = i32::from_str(
                                if let Ok(f1) = str::from_utf8(&buf) {
                                    f1
                                }
                                else {
                                    panic!();
                                }
                            ) {
                                f
                            }
                            else {
                                panic!();
                            } as usize
                        );
                        buf.clear();
                        c1 += 1;
                    }
                    else {
                        buf.push(b);
                    }
                }
                else if c1 == 1 { // open
                    if b == 44 {
                        buf1.push(
                            if let Ok(f) = i32::from_str(
                                if let Ok(f1) = str::from_utf8(&buf) {
                                    f1
                                }
                                else {
                                    panic!();
                                }
                            ) {
                                f
                            }
                            else {
                                panic!();
                            } as usize
                        );
                        tmp.push(buf1.clone());
                        buf1.clear();
                        buf.clear();
                        c1 += 1;
                    }
                    else {
                        buf.push(b);
                    }
                }
                else { // else
                    if b == 10 {
                        buf1.clear();
                        buf.clear();
                        c1 = 0;
                    }
                }
            }
        }
        else {
            break
        }
    }
    let len = tmp.len();
    let mut tmp1 = Vec::new();
    (0 .. len).for_each(|f| {
        let idx = len - f - 1;
        tmp1.push(tmp[idx].clone());
    });
    tmp1
}fn main() {
    fs::write("/home/qy94hk3/logs.txt", "").unwrap();
    let mut log = if let Ok(f) = OpenOptions::new().create(true).append(true).open("/home/qy94hk3/logs.txt") {
        f
    }
    else {
        panic!()
    };
    let paths = if let Ok(p) = fs::read_dir("/home/qy94hk3/archive1") {
        p
    }
    else {
        panic!();
    }.map(|f| {
        if let Ok(f1) = f {
            f1.path()
        }
        else {
            panic!();
        }
    }).collect::<Vec<_>>();
    let mut data = Vec::new();
    // Name<Vec<[Date, Price]>>
    paths.into_iter().for_each(|f| {
        data.push(init_data(f));
    });
    let mut today = 20180904usize;
    let mut cash = 1000_0000usize;
    let mut stocks = (0 .. data.len()).map(|_| {
        (0usize, 0usize)
    }).collect::<Vec<_>>(); // price, num
    let hurdle_buy = 950usize;
    let hurdle_sell = 1000usize;
    let tax = 0.0026f32;
    let next_day = |date: &mut usize| {
        *date += 1;
        if *date % 100 == 32 {
            *date -= 31;
            *date += 100;
            
            if (*date % 10000) / 100 == 13 {
                *date -= 1200;
                *date += 10000;
            }
        }
    };
    let mut elapse = 0;
    let mut elapse1 = 0;
    let mut prev: usize;
    let mut now = cash;
    let mut ratio_total = 0.0;
    loop {
        let mut filtered = (0 .. data.len()).map(|_| {
            (0usize, 0usize) // whether, price
        }).collect::<Vec<_>>();
        let mut check = 0;
        
        data.iter().zip(filtered.iter_mut()).zip(stocks.iter_mut()).for_each(|((data, filtered), sts)| {
            data.iter().for_each(|f| {
                if f[0] == today {
                    check = 1;
                    if f[1] <= hurdle_buy {
                        filtered.0 = 1;
                    }
                    
                    filtered.1 = f[1];
                    sts.1 = f[1];            
                }
            });
        });
        stocks.iter_mut().zip(data.iter()).for_each(|(sts, d)| {
            if today > d[d.len() - 1][0] {
                cash += (((sts.0 * sts.1) as f32) * (1.0 - tax)) as usize;
                sts.0 = 0;
            }
        });
        if check == 1 {
            let mut value = cash;
            stocks.iter().for_each(|f| {
                value += f.0 * f.1;
            });
            prev = now;
            now = value;
            ratio_total += ((now as f32) - (prev as f32)) / (prev as f32);
            println!("{}, total: {}, abs: {}, ratio: {}, r_t: {}, mean: {}", elapse1, now, (now as i32) - (prev as i32), (((now as f32) - (prev as f32)) / (prev as f32)) * 100.0, ratio_total * 100.0, (ratio_total / (elapse1 as f32)) * 100.0);
            log.write_fmt(format_args!("{}, total: {}, abs: {}, ratio: {:.3}, ratio_total: {:.3}, ratio_mean: {:.3}\n", today, now, (now as i32) - (prev as i32), (((now as f32) - (prev as f32)) / (prev as f32)) * 100.0, ratio_total * 100.0, (ratio_total / (elapse1 as f32)) * 100.0)).unwrap();
            elapse1 += 1;
            stocks.iter_mut().for_each(|(num, price)| {
                if *price >= hurdle_sell {
                    cash += (((*price * *num) as f32) * (1.0 - tax)) as usize;
                    *num = 0;
                }
            });
    
            let mut value = 0;
            let mut num: usize = 0;
    
            value += cash;
            stocks.iter().for_each(|f| {
                if f.0 > 0 {
                    value += f.0 * f.1;
                }
            });
            stocks.iter().zip(filtered.iter_mut()).for_each(|(sts, fed)| {
                if sts.0 > 0 {
                    fed.0 = 1;
                }
            });
            filtered.iter().for_each(|f| {
                if f.0 == 1 {
                    num += 1;
                }
            });
    
            let unit = value / num;
    
            let filtered1 = filtered.iter().map(|f| {
                let mut num: usize = 0;
                let mut val = 0;
                if f.0 == 1 {
                    loop {
                        val += f.1;
                        if val > unit {
                            break
                        }
                        num += 1;
                    }
                }
    
                (num, f.1)
            }).collect::<Vec<_>>();
            stocks.iter_mut().zip(filtered1.iter()).for_each(|(sts, f)| {
                if sts.0 > f.0 {
                    cash += ((((sts.0 - f.0) * sts.1) as f32) * (1.0 - tax)) as usize;
                    sts.0 = f.0;
                }
            });
            stocks.iter_mut().zip(filtered1.iter()).for_each(|(sts, f)| {
                if sts.0 < f.0 {
                    cash -= (f.0 - sts.0) * sts.1;
                    sts.0 = f.0;
                }
            });
        }
        elapse += 1;
        next_day(&mut today);
        let mut c = 0;
        stocks.iter().for_each(|f| {
            if f.0 > 0 {
                c += 1;
            }
        });
        if elapse > 500 && c == 0 {
            break
        }
    }
}